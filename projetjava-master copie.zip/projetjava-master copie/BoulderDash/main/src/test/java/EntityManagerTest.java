


import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import projet.tilegame.Handler;
import projet.tilegame.entities.EntityManager;
import projet.tilegame.entities.creatures.Player;



public class EntityManagerTest {
	
	private Handler handler;
	private Player player;
	private EntityManager entityManager;
	private ArrayList<entity> entities;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		this.entityManager = new EntityManager(handler, player);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetHandler() {
		final Handler expected = handler;
		assertEquals(expected, this.entityManager.getHandler());
	}
	
	@Test
	public void testGetPlayer(){
		final Player expected = player;
		assertEquals (expected, this.entityManager.getPlayer());
	}
	
	@Test
	public void testGetEntities(){
		final ArrayList<Entity> expected = entities;
		assertEquals (expected, this.entityManager.getEntities());
	}

}
