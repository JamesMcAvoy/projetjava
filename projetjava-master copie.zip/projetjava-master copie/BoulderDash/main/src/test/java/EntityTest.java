

import static org.junit.Assert.*;

import java.awt.Rectangle;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;
import projet.tilegame.entities.Entity;

public class EntityTest {

	private Entity entities;
	private Rectangle bounds;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetX() {
		final float expected = 4;
		assertEquals(expected,4, 5);
		
	}
	@Test
	public void testGetY(){
		final float expected = 4;
		assertEquals(expected,4, 5);
	}
	
	@Test 
	public void testGetWidth(){
		final float expected = 32;
		assertEquals(expected ,this.entities.getWidth());
	}

	@Test
	public void testGetHeight(){
		final float expected = 32;
		assertEquals(expected, this.entities.getHeight());
	}
	
	@Test
	public void testGetCollisionBounds(){
		final Rectangle expected = bounds;
		assertEquals(expected, this.entities.getCollisionBounds(1, 1));
		
	}
	
}
