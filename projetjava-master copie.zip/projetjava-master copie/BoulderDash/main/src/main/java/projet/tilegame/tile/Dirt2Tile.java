package projet.tilegame.tile;

import projet.tilegame.graphics.Assets;

public class Dirt2Tile extends Tile {
/**
 * Tile of a Dirt2
 * @param id
 */
	public Dirt2Tile( int id) {
		super(Assets.dirt2, id);
		
	}
}
