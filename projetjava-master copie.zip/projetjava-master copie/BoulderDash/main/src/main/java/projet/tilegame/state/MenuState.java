package projet.tilegame.state;

import java.awt.Graphics;

import projet.tilegame.Handler;

public class MenuState extends State{


	public MenuState(Handler handler){
		super(handler);
		
	}
	
	@Override
	public void tick() {
		
	}

	@Override
	public void render(Graphics g) {
		
		
	}

}
