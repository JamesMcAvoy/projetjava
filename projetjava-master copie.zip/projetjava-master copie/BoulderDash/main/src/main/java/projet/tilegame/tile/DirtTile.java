package projet.tilegame.tile;

import projet.tilegame.graphics.Assets;

public class DirtTile  extends Tile{
/**
 * Tile of a Dirt
 * @param id
 */
	public DirtTile( int id) {
		super(Assets.dirt, id);
		
	}
	


}
