package dev.codemore.tilegame.tile;

import java.awt.image.BufferedImage;

import dev.codemore.tilegame.gfx.Assets;

public class GrassTile extends Tile {

	public GrassTile( int id) {
		super(Assets.grass, id);
		
	}
	


}
