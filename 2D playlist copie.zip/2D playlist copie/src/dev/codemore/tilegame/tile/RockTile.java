package dev.codemore.tilegame.tile;

import java.awt.image.BufferedImage;

import dev.codemore.tilegame.gfx.Assets;

public class RockTile extends Tile{

	public RockTile( int id) {
		super(Assets.wall, id);
		
	}
	
	@Override
	public boolean isSolid(){
		return true;
	}

}
