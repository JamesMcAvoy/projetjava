package dev.codemore.tilegame.tile;

import java.awt.image.BufferedImage;

import dev.codemore.tilegame.gfx.Assets;

public class DirtTile  extends Tile{

	public DirtTile( int id) {
		super(Assets.dirt, id);
		
	}
	


}
