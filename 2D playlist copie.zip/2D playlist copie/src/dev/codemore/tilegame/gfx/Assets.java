package dev.codemore.tilegame.gfx;

import java.awt.image.BufferedImage;

public class Assets {
	
	public static final int width = 16, height = 16;
	public static BufferedImage wall, dirt, grass, stone, diamons;
	public static BufferedImage[] player_down, player_up, player_left, player_right;
	
	
	public static void init(){
		SpriteSheet sheet = new SpriteSheet(ImageLoader.LoadImage("/textures/Boulder copie.png"));
		SpriteSheet sheet2 = new SpriteSheet(ImageLoader.LoadImage("/textures/player.png"));
		
		player_down = new BufferedImage[2];
		player_up = new BufferedImage[1];
		player_left = new BufferedImage[2];
		player_right = new BufferedImage[2];
		
		player_down[0] = sheet2.crop(0, 0, width, height);
		player_down[1] = sheet2.crop(width, 0, width, height);
		player_up[0] = sheet2.crop(width*2, height*5 , width, height);
		player_left[0] = sheet2.crop(0, height, width, height);
		player_left[1] = sheet2.crop(width, height, width, height);
		player_right[0] = sheet2.crop(0, height*3 , width, height);
		player_right[1] = sheet2.crop(width, height*3, width, height);
		
		
		wall = sheet.crop(0, 0, width, height);
		dirt = sheet.crop(width, 0, width, height);
		grass = sheet.crop(width*2, 2, width, height);
		stone = sheet.crop(width*3, 3, width, height);
		diamons = sheet.crop(width*5, 0, width, height);
		
	//	player = sheet2.crop(0, 0, width, height);
		
	}

}
