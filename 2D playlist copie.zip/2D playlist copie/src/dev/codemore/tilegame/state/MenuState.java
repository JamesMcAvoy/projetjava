package dev.codemore.tilegame.state;

import java.awt.Graphics;

import dev.codemore.tilegame.Game;
import dev.codemore.tilegame.Handler;

public class MenuState extends State{


	public MenuState(Handler handler){
		super(handler);
		
	}
	
	@Override
	public void tick() {
		
	}

	@Override
	public void render(Graphics g) {
		
		
	}

}
