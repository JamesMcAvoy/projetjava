package dev.codemore.tilegame;

import dev.codemore.tilegame.display.Display;

public class launcher {
	public static void main (String[] args){
		
		Game game =new Game("title", 500, 500);
		game.start();
	}

}
